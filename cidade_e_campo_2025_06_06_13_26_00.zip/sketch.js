// --- Variáveis Globais ---
let carros = []; // Armazena objetos Carro
let arvores = []; // Armazena objetos Arvore (para o campo)
let predios = []; // Armazena objetos Predio (para a cidade)
let semaforos = []; // Armazena objetos Semaforo (para a cidade)
let nuvens = []; // Armazena objetos Nuvem (para o céu)
let gotasChuva = []; // Armazena as gotas de chuva
let chovendo = false; // Estado da chuva
let chanceChuva = 0.0005; // Pequena chance de começar a chover a cada frame (ajuste para mais ou menos frequência)

let tempo = 0; // Controla o ciclo dia/noite (0 a 255)
let velocidadeCicloTempo = 0.3; // Velocidade da transição (0.1 para mais lento, 1 para mais rápido)
let modoCena = 'campo'; // 'campo' ou 'cidade'

// Cores pré-definidas para o céu e outros elementos
let corCeuDia;
let corCeuNoite;
let corSol;
let corLua;

// --- Funções Essenciais do p5.js ---
function setup() {
  createCanvas(windowWidth, 600); // Tela responsiva na largura
  rectMode(CENTER); // Facilita o posicionamento de retângulos (como carros e prédios)

  // Inicializa as cores
  corCeuDia = color(135, 206, 235); // Azul céu
  corCeuNoite = color(25, 25, 112); // Azul marinho escuro
  corSol = color(255, 220, 0); // Amarelo sol
  corLua = color(200, 200, 255); // Azulado claro para a lua

  // Gera os elementos iniciais para a cena de campo
  gerarElementosCena('campo');
}

function draw() {
  // --- Atualiza o tempo e controla o ciclo dia/noite ---
  tempo += velocidadeCicloTempo;
  if (tempo > 255) {
    tempo = 0; // Reinicia o ciclo
    // Pequena chance de começar/parar de chover ao reiniciar o ciclo
    if (modoCena === 'cidade') {
        if (random(1) < 0.2) { // 20% de chance de mudar o estado da chuva
            chovendo = !chovendo; // Inverte o estado da chuva
            if (chovendo && gotasChuva.length === 0) { // Se começou a chover, gera as gotas
                for (let i = 0; i < 300; i++) {
                    gotasChuva.push(new GotaChuva(random(width), random(height)));
                }
            } else if (!chovendo) { // Se parou de chover, limpa as gotas
                gotasChuva = [];
            }
        }
    }
  }

  // --- Desenha o céu com gradiente ---
  let col1 = lerpColor(corCeuDia, corCeuNoite, tempo / 255); // Cor do topo do céu
  let col2 = lerpColor(color(173, 216, 230), color(0, 0, 0), tempo / 255); // Cor do horizonte
  for (let y = 0; y < height; y++) {
    let inter = map(y, 0, height, 0, 1);
    let c = lerpColor(col1, col2, inter);
    stroke(c);
    line(0, y, width, y);
  }
  noStroke(); // Garante que outras formas não tenham contorno

  // --- Desenha o sol ou a lua ---
  desenharSolLua(tempo);

  // --- Exibe e move as nuvens (em ambas as cenas) ---
  for (let nuvem of nuvens) {
    nuvem.mover();
    nuvem.exibir(tempo);
  }

  // --- Desenha o chão e a estrada ---
  desenharChao(modoCena);
  desenharEstrada(modoCena);

  // --- Exibe elementos específicos da cena (árvores ou prédios) ---
  if (modoCena === 'campo') {
    for (let arvore of arvores) {
      arvore.exibir();
    }
  } else { // cidade
    for (let predio of predios) {
      predio.exibir(tempo); // Passa o tempo para controlar as luzes do prédio
    }
    // Exibe semáforos (apenas na cidade)
    for (let semaforo of semaforos) {
      semaforo.exibir();
    }
  }

  // --- Exibe e move os carros ---
  for (let carro of carros) {
    carro.mover();
    carro.exibir(tempo); // Passa o tempo para controlar as luzes dos faróis
  }

  // --- Lógica e Exibição da Chuva (apenas na cidade e à noite) ---
  if (modoCena === 'cidade' && chovendo) {
    for (let gota of gotasChuva) {
      gota.cair();
      gota.exibir(tempo);
    }
  }
}

// --- Funções Auxiliares de Desenho de Cenário ---

function desenharSolLua(tempoAtual) {
  noStroke();
  let xSolLua;
  let ySolLua;
  let alphaSolLua;

  if (tempoAtual < 127) { // Fase do Dia (0 a 126)
    xSolLua = map(tempoAtual, 0, 127, width * 0.2, width * 0.8);
    ySolLua = map(tempoAtual, 0, 127, height * 0.8, height * 0.2); // Sobe no céu
    alphaSolLua = map(tempoAtual, 0, 127, 0, 255); // Aparece gradualmente

    fill(corSol, alphaSolLua);
    ellipse(xSolLua, ySolLua, 60);

  } else { // Fase da Noite (127 a 255)
    xSolLua = map(tempoAtual, 127, 255, width * 0.8, width * 0.2);
    ySolLua = map(tempoAtual, 127, 255, height * 0.2, height * 0.8); // Desce no céu
    alphaSolLua = map(tempoAtual, 127, 255, 255, 0); // Desaparece gradualmente

    fill(corLua, alphaSolLua);
    ellipse(xSolLua, ySolLua, 50);

    // Estrelas aparecendo
    if (tempoAtual > 180) { // Começa a mostrar estrelas quando está bem escuro
      fill(255, 255, 255, map(tempoAtual, 180, 255, 0, 255));
      for (let i = 0; i < 70; i++) {
        ellipse(random(width), random(height * 0.5), random(1, 3));
      }
    }
  }
}

function desenharChao(cena) {
  noStroke();
  if (cena === 'campo') {
    // Grama em primeiro plano
    fill(70, 150, 70); // Verde grama
    rect(width / 2, height * 0.925, width, height * 0.15);

    // Colinas ao fundo (verde mais escuro)
    fill(60, 130, 60);
    beginShape();
    vertex(0, height * 0.6);
    curveVertex(0, height * 0.6); // Ponto de controle
    curveVertex(width * 0.2, height * 0.5);
    curveVertex(width * 0.5, height * 0.55);
    curveVertex(width * 0.8, height * 0.45);
    curveVertex(width, height * 0.5);
    curveVertex(width, height * 0.5); // Ponto de controle
    vertex(width, height * 0.7); // Encontra a estrada
    vertex(0, height * 0.7);
    endShape(CLOSE);

  } else { // cidade
    // Calçada
    fill(180); // Cinza claro
    rect(width / 2, height * 0.925, width, height * 0.15);

    // Fundo da cidade (edifícios mais distantes/área cinzenta)
    fill(120, 120, 130);
    rect(width / 2, height * 0.6, width, height * 0.2);
  }
}

function desenharEstrada(cena) {
  noStroke();
  if (cena === 'campo') {
    // Estrada de Terra Sinuosa
    fill(139, 69, 19); // Marrom
    beginShape();
    vertex(0, height * 0.7);
    curveVertex(0, height * 0.7);
    curveVertex(width * 0.2, height * 0.72);
    curveVertex(width * 0.5, height * 0.7);
    curveVertex(width * 0.8, height * 0.73);
    curveVertex(width, height * 0.7);
    curveVertex(width, height * 0.7);

    vertex(width, height * 0.85);
    curveVertex(width, height * 0.85);
    curveVertex(width * 0.8, height * 0.82);
    curveVertex(width * 0.5, height * 0.85);
    curveVertex(width * 0.2, height * 0.8);
    curveVertex(0, height * 0.85);
    curveVertex(0, height * 0.85);
    endShape(CLOSE);

    // Detalhes da estrada (cascalho)
    fill(100, 50, 10, 150); // Com um pouco de transparência
    for (let i = 0; i < 150; i++) {
      ellipse(random(width), random(height * 0.7, height * 0.85), random(1, 3), random(1, 3));
    }

  } else { // cidade
    // Asfalto
    fill(50); // Asfalto cinza escuro
    rect(width / 2, height * 0.775, width, height * 0.15);

    // Faixas da estrada
    fill(255, 255, 0); // Faixa amarela central
    rect(width / 2, height * 0.775, width, 5);

    fill(255); // Faixas brancas intermitentes
    for (let i = 0; i < width + 80; i += 80) {
      rect(i, height * 0.775 - 10, 40, 3); // Faixa de cima
      rect(i, height * 0.775 + 12, 40, 3); // Faixa de baixo
    }

    // Postes de Luz
    for (let i = 0; i < width; i += 200) {
      fill(100);
      rect(i + 50, height * 0.65, 5, 50); // Poste
      if (tempo > 150) { // Acende à noite
        fill(255, 255, 100, map(tempo, 150, 255, 0, 255)); // Luz amarela com glow
        ellipse(i + 52, height * 0.65, 20, 20); // Luz
      }
    }
  }
}

// --- Gerenciamento de Elementos da Cena ---

function gerarElementosCena(cena) {
  // Limpa os arrays para a nova cena
  carros = [];
  arvores = [];
  predios = [];
  semaforos = [];
  nuvens = []; // Nuvens são geradas para ambas as cenas
  gotasChuva = []; // Garante que a chuva seja resetada

  // Gera as nuvens para ambas as cenas (ou apenas cidade, se preferir)
  for (let i = 0; i < 5; i++) {
    nuvens.push(new Nuvem(random(width), random(0, height * 0.4), random(80, 200), random(30, 80)));
  }

  if (cena === 'campo') {
    // Geração de árvores com frutas
    for (let i = 0; i < 15; i++) {
      arvores.push(new Arvore(random(width), random(height * 0.4, height * 0.65), random(80, 150)));
    }
    // Geração de carros de campo
    for (let i = 0; i < 4; i++) {
      carros.push(new Carro(random(width), height * 0.75, random(1, 3), 'campo'));
    }
  } else { // cidade
    // Geração de prédios
    for (let i = 0; i < 20; i++) {
      predios.push(new Predio(random(width), height * 0.6 - random(50, 300), random(50, 100), random(100, 400)));
    }
    // Geração de carros de cidade
    for (let i = 0; i < 8; i++) {
      carros.push(new Carro(random(width), height * 0.775, random(3, 7), 'cidade'));
    }
    // Geração de semáforos
    semaforos.push(new Semaforo(width * 0.25, height * 0.65));
    semaforos.push(new Semaforo(width * 0.75, height * 0.65));
    semaforos.push(new Semaforo(width * 0.5, height * 0.7, 'horizontal'));

    // Garante que a chuva seja inicializada se estiver chovendo
    if (chovendo) {
        for (let i = 0; i < 300; i++) {
            gotasChuva.push(new GotaChuva(random(width), random(height)));
        }
    }
  }
}

// --- Interatividade ---

function mousePressed() {
  // Troca o modo da cena e regenera os elementos
  modoCena = (modoCena === 'campo') ? 'cidade' : 'campo';
  gerarElementosCena(modoCena);
  tempo = 0; // Reinicia o tempo para uma transição suave da cena
  chovendo = false; // Garante que não chove imediatamente ao trocar de cena
  gotasChuva = [];
}

// --- Classes dos Elementos ---

class Carro {
  constructor(x, y, velocidade, tipo) {
    this.x = x;
    this.y = y;
    this.velocidade = velocidade;
    this.tipo = tipo;
    this.largura = (tipo === 'campo') ? 50 : random(60, 90); // Larguras variadas para carros da cidade
    this.altura = (tipo === 'campo') ? 25 : random(30, 45); // Alturas variadas
    this.cor = (tipo === 'campo') ? color(random(80, 180), random(60, 120), random(30, 80)) : color(random(50, 255), random(50, 255), random(50, 255));
    this.corJanela = color(100, 150, 200);
    this.corRoda = color(50);
    this.formato = (tipo === 'campo') ? 0 : floor(random(3)); // 0: padrão, 1: van/caminhonete, 2: carro esportivo
  }

  mover() {
    this.x += this.velocidade;
    // Se o carro sair da tela, ele reaparece do outro lado com uma nova posição e velocidade
    if (this.x - this.largura / 2 > width) {
      this.x = -this.largura / 2 - random(width / 4); // Reaparece mais longe para simular fluxo contínuo
      this.velocidade = (this.tipo === 'campo') ? random(1, 3) : random(3, 7);
      this.cor = (this.tipo === 'campo') ? color(random(80, 180), random(60, 120), random(30, 80)) : color(random(50, 255), random(50, 255), random(50, 255));
      this.formato = (this.tipo === 'campo') ? 0 : floor(random(3));
    }
  }

  exibir(tempoAtual) {
    push();
    translate(this.x, this.y);

    fill(this.cor);
    noStroke();

    // Desenha o corpo do carro baseado no formato
    switch (this.formato) {
      case 0: // Carro padrão (retangular com teto)
        rect(0, 0, this.largura, this.altura); // Corpo
        rect(0, -this.altura * 0.5, this.largura * 0.8, this.altura * 0.5); // Teto
        break;
      case 1: // Van / Caminhonete (mais longo, teto mais alto/plano)
        rect(0, 0, this.largura * 1.2, this.altura * 1.1); // Corpo maior
        rect(0, -this.altura * 0.55, this.largura * 1.1, this.altura * 0.6); // Teto um pouco mais alto
        break;
      case 2: // Carro esportivo (mais baixo, mais inclinado)
        beginShape();
        vertex(-this.largura * 0.5, this.altura * 0.5); // Canto inferior esquerdo
        vertex(this.largura * 0.5, this.altura * 0.5); // Canto inferior direito
        vertex(this.largura * 0.4, -this.altura * 0.2); // Topo traseiro
        vertex(-this.largura * 0.4, -this.altura * 0.2); // Topo dianteiro
        endShape(CLOSE);
        // Teto inclinado para esportivo
        beginShape();
        vertex(-this.largura * 0.35, -this.altura * 0.2);
        vertex(this.largura * 0.35, -this.altura * 0.2);
        vertex(this.largura * 0.2, -this.altura * 0.5);
        vertex(-this.largura * 0.2, -this.altura * 0.5);
        endShape(CLOSE);
        break;
    }


    // Janelas
    fill(this.corJanela);
    if (this.formato === 0 || this.formato === 1) { // Janelas padrão
      rect(this.largura * 0.15, -this.altura * 0.4, this.largura * 0.25, this.altura * 0.4);
      rect(-this.largura * 0.15, -this.altura * 0.4, this.largura * 0.25, this.altura * 0.4);
    } else if (this.formato === 2) { // Janelas para carro esportivo
      rect(this.largura * 0.1, -this.altura * 0.35, this.largura * 0.2, this.altura * 0.25);
      rect(-this.largura * 0.1, -this.altura * 0.35, this.largura * 0.2, this.altura * 0.25);
    }


    // Rodas
    fill(this.corRoda);
    ellipse(-this.largura * 0.35, this.altura * 0.5, this.largura * 0.2, this.largura * 0.2);
    ellipse(this.largura * 0.35, this.altura * 0.5, this.largura * 0.2, this.largura * 0.2);

    // Faróis e Lanternas (acendem à noite com cone de luz)
    if (tempoAtual > 150) { // Após um certo ponto na transição noturna
      let opacidadeLuz = map(tempoAtual, 150, 255, 0, 255);

      // Faróis Dianteiros (amarelo)
      fill(255, 255, 0, opacidadeLuz);
      ellipse(this.largura * 0.45, -this.altura * 0.1, 8); // Farol esquerdo
      ellipse(this.largura * 0.35, -this.altura * 0.1, 8); // Farol direito

      // Cone de luz dos faróis
      noStroke();
      fill(255, 255, 150, opacidadeLuz * 0.2); // Amarelo claro e mais transparente
      beginShape();
      vertex(this.largura * 0.4, -this.altura * 0.1); // Ponto de origem próximo ao farol
      vertex(this.largura * 0.4 + 40, this.altura * 0.5 + 10); // Ponto na estrada à frente
      vertex(this.largura * 0.4 + 40, this.altura * 0.7); // Ponto mais largo na estrada
      vertex(this.largura * 0.4 - 40, this.altura * 0.7); // Outro ponto mais largo
      vertex(this.largura * 0.4 - 40, this.altura * 0.5 + 10); // Ponto na estrada à frente
      endShape(CLOSE);


      // Lanternas Traseiras (vermelho)
      fill(255, 0, 0, opacidadeLuz);
      ellipse(-this.largura * 0.45, -this.altura * 0.1, 8); // Lanterna esquerda
      ellipse(-this.largura * 0.35, -this.altura * 0.1, 8); // Lanterna direita
    }
    pop();
  }
}

class Arvore {
  constructor(x, y, altura) {
    this.x = x;
    this.y = y;
    this.altura = altura;
    this.corTronco = color(139, 69, 19); // Marrom
    this.corFolhas = color(34, 139, 34); // Verde floresta
    this.corFruta = color(255, 0, 0); // Vermelho para frutas
    this.frutas = [];

    // Geração de frutas aleatoriamente na copa
    for (let i = 0; i < random(10, 25); i++) {
      this.frutas.push({
        x: random(-this.altura * 0.25, this.altura * 0.25),
        y: random(-this.altura * 0.35, this.altura * 0.1),
        tamanho: random(3, 7)
      });
    }
  }

  exibir() {
    push();
    translate(this.x, this.y);

    // Tronco
    fill(this.corTronco);
    rect(0, 0, this.altura * 0.2, this.altura);

    // Copa da árvore (forma de nuvem mais orgânica)
    fill(this.corFolhas);
    ellipse(0, -this.altura * 0.3, this.altura * 0.8, this.altura * 0.7);
    ellipse(-this.altura * 0.2, -this.altura * 0.1, this.altura * 0.6, this.altura * 0.5);
    ellipse(this.altura * 0.2, -this.altura * 0.1, this.altura * 0.6, this.altura * 0.5);

    // Frutas
    fill(this.corFruta);
    for (let fruta of this.frutas) {
      ellipse(fruta.x, fruta.y, fruta.tamanho);
    }

    pop();
  }
}

class Predio {
  constructor(x, y, largura, altura) {
    this.x = x;
    this.y = y;
    this.largura = largura;
    this.altura = altura;
    this.corBase = color(random(100, 200), random(100, 200), random(100, 200)); // Tons de cinza/azulado variados
    this.janelas = [];

    // Geração de janelas com estado inicial de iluminação
    // Posicionamento das janelas agora é relativo ao centro do prédio
    for (let j = 0; j < floor(this.altura / 25); j++) {
      for (let i = 0; i < floor(this.largura / 25); i++) {
        this.janelas.push({
          x: -this.largura / 2 + 5 + i * 20, // Posição X da janela
          y: -this.altura / 2 + 5 + j * 20, // Posição Y da janela
          acesa: random() > 0.6 // Algumas acesas por padrão
        });
      }
    }
  }

  exibir(tempoAtual) {
    push();
    translate(this.x, this.y);

    fill(this.corBase);
    // Corpo do prédio (desenhado com o centro em (0,0) devido ao rectMode(CENTER))
    rect(0, 0, this.largura, this.altura);

    // Telhado (simples)
    fill(70);
    rect(0, -this.altura / 2, this.largura, 5); // No topo do prédio

    // Janelas
    for (let janela of this.janelas) {
      let corJanela;
      if (tempoAtual > 150) { // Se for noite
        corJanela = janela.acesa ? color(255, 200, 0) : color(30, 30, 50); // Amarelo ou escuro
      } else { // Dia
        corJanela = color(100, 100, 120); // Todas escuras durante o dia
      }
      fill(corJanela);
      rect(janela.x, janela.y, 10, 10);
    }
    pop();
  }
}

class Semaforo {
  constructor(x, y, orientacao = 'vertical') {
    this.x = x;
    this.y = y;
    this.largura = 20;
    this.altura = (orientacao === 'vertical') ? 60 : 20;
    this.estado = floor(random(3)); // 0: vermelho, 1: amarelo, 2: verde
    this.timer = 0;
    this.intervalo = 180; // Tempo em frames para mudar de cor (ajuste para mais ou menos rápido)
    this.orientacao = orientacao;
  }

  exibir() {
    push();
    translate(this.x, this.y);

    // Poste do semáforo
    fill(80);
    rect(0, (this.orientacao === 'vertical') ? 0 : -20, 5, (this.orientacao === 'vertical') ? 80 : 5);

    // Corpo do semáforo
    fill(30);
    if (this.orientacao === 'vertical') {
      rect(0, -this.altura / 2 + 5, this.largura, this.altura);
    } else {
      rect(this.largura / 2, 0, this.largura, this.altura);
    }

    // Luzes do semáforo
    noStroke();
    // Vermelho
    fill((this.estado === 0) ? color(255, 0, 0) : color(50, 0, 0));
    if (this.orientacao === 'vertical') {
      ellipse(0, -this.altura * 0.33, 15);
    } else {
      ellipse(this.largura * 0.33, 0, 15);
    }

    // Amarelo
    fill((this.estado === 1) ? color(255, 255, 0) : color(50, 50, 0));
    if (this.orientacao === 'vertical') {
      ellipse(0, 0, 15);
    } else {
      ellipse(0, 0, 15);
    }

    // Verde
    fill((this.estado === 2) ? color(0, 255, 0) : color(0, 50, 0));
    if (this.orientacao === 'vertical') {
      ellipse(0, this.altura * 0.33, 15);
    } else {
      ellipse(-this.largura * 0.33, 0, 15);
    }
    pop();

    this.atualizarEstado();
  }

  atualizarEstado() {
    this.timer++;
    if (this.timer > this.intervalo) {
      this.estado = (this.estado + 1) % 3; // Muda para a próxima cor (0, 1, 2)
      this.timer = 0;
    }
  }
}

class Nuvem {
  constructor(x, y, largura, altura) {
    this.x = x;
    this.y = y;
    this.largura = largura;
    this.altura = altura;
    this.velocidade = random(0.1, 0.5); // Nuvens se movem em velocidades diferentes
  }

  mover() {
    this.x += this.velocidade;
    // Se a nuvem sair da tela, reaparece do outro lado
    if (this.x - this.largura / 2 > width + 50) { // Adiciona uma margem para suavizar o reaparecimento
      this.x = -this.largura / 2 - random(50, 100);
      this.y = random(0, height * 0.4); // Posição vertical aleatória no céu
      this.largura = random(80, 200);
      this.altura = random(30, 80);
      this.velocidade = random(0.1, 0.5);
    }
  }

  exibir(tempoAtual) {
    push();
    translate(this.x, this.y);
    noStroke();

    // Opacidade da nuvem muda com o ciclo dia/noite
    let alphaNuvem = map(tempoAtual, 0, 255, 200, 50); // Mais visível de dia, mais sutil de noite

    // Cor da nuvem (mais clara de dia, mais escura/azulada de noite)
    let corNuvem = lerpColor(color(255, 255, 255, alphaNuvem), color(100, 120, 150, alphaNuvem), tempoAtual / 255);
    fill(corNuvem);

    // Formato de nuvem (elipses sobrepostas)
    ellipse(0, 0, this.largura, this.altura);
    ellipse(this.largura * 0.3, this.altura * 0.2, this.largura * 0.6, this.altura * 0.8);
    ellipse(-this.largura * 0.3, this.altura * 0.2, this.largura * 0.6, this.altura * 0.8);
    ellipse(this.largura * 0.1, -this.altura * 0.2, this.largura * 0.7, this.altura * 0.7);
    pop();
  }
}

class GotaChuva {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.velocidade = random(5, 15);
    this.comprimento = random(10, 20);
  }

  cair() {
    this.y += this.velocidade;
    if (this.y > height) { // Se a gota sair da tela, reseta
      this.y = random(-200, 0); // Reaparece acima da tela
      this.x = random(width);
    }
  }

  exibir(tempoAtual) {
    // Só mostra a chuva à noite
    if (tempoAtual > 150) {
      let opacidadeChuva = map(tempoAtual, 150, 255, 0, 150); // Fica mais visível à noite
      stroke(200, 200, 255, opacidadeChuva); // Cor azulada com opacidade
      strokeWeight(1.5);
      line(this.x, this.y, this.x, this.y + this.comprimento);

      // Reflexo sutil no asfalto (opcional, pode ser pesado para muitas gotas)
      if (modoCena === 'cidade') {
        stroke(200, 200, 255, opacidadeChuva * 0.3); // Mais transparente
        line(this.x, height * 0.775, this.x + random(-2, 2), height * 0.775 + random(5, 15));
      }
    }
  }
}